#ifndef SOLUCION_AUXILIARES_H
#define SOLUCION_AUXILIARES_H

#include "definiciones.h"


#endif //SOLUCION_AUXILIARES_H
///////// ejercicio 1

bool esMatrizDeNxM (vector<vector<int>> mat,int n,int m);
bool sinHogaresRepetidos(eph_h th, int h );
bool sinIndividuosRepetidos(eph_i ti , int n);
bool sinRepetidos(eph_h th, eph_i ti , int n, int h );
bool anioYtrimestreIguales(eph_h th, eph_i ti , int n, int h );
bool pertenece (vector <int> v, int x);
bool estanAsociados(eph_h th, eph_i ti , int n ,int h);
bool menosDe20Personas(eph_i ti , int n);
bool IV2_MayorIgual_II2(eph_h th, int h);
bool categoricosIndividuoEnRango(eph_i ti , int n);
bool categoricosHogarEnRango(eph_h th, int h);
bool categoricosEnRango(eph_h th, eph_i ti, int n ,int h);

//////////////// fin ejercicio 1
///// ejercicio 2
int maxHabitacionesDeRegion (eph_h th,int h,int region);
///// fin ejercicio 2
////////////////// ejercicio 3
int contarApariciones(vector <int> v, int x);
vector <int> vectorCodosuIndividuo(eph_i ti, int n);
vector <int> vectorCodosuHogar(eph_h th, int h);
vector<int> hcPorRegion(eph_i ti, int n,eph_h th, int h);
vector<int> casaPorRegion(eph_h th,int h);
vector<pair<int,float>> indiceHcRegion(eph_i ti, int n,eph_h th, int h);
///////////// fin ejercicio 3

//////////// ejercicio 4
int teleWorkers(eph_h th, int h, eph_i ti, int n);
int trabjadoresTotales(eph_i ti, int n);
bool mismoTrimestre( eph_h t1h,  eph_h t2h);
/////////// fin ejercicio 4
////////////// ejercicio 5
bool tieneCasaPropia(hogar h);
int cantHabitantes(hogar h, eph_i ti);
bool tieneCasaChica(hogar h, eph_i ti);
////// fin ejercicio 5
/////////// ejercicio 6
vector<int> generaFilaHogares(eph_h th,int i);
vector<int> generaFilaIndividuos(eph_i ti,int i);
void agregarIndividuosCorrespondientes(hogar h, eph_i ti, vector<par_hi> & resultado);
///////////// fin ejercicio 6
//////////////// ejercicio 7
void burbujeoHogares(eph_h &th,int h);
eph_h ordenarHogares (eph_h th,int h);
int buscarIndiceCodosu(int codosu, eph_h th);
int buscarIndiceCodosu(int codosu, eph_h th);
bool estaAntesHogar(individuo individuo1, individuo individuo2, eph_h th);
void swap(eph_i &ti, int i, int j);
void ordenarIndividuos(eph_i &ti , int n, eph_h thOrdenado);
//////////////////////// ejercicio 8
void swap(vector<int> &lista, int i, int j);
int ingresoDelHogar(eph_i ti, int n , int codosu);
vector<pair <int,int>> parCodosuIngreso(eph_i ti,int n,eph_h th,int h);
void burbujeoIngresos(vector<pair <int,int>> &codosuIngreso);
void ordenarParPorIngreso(vector<pair <int,int>> &codosuIngreso);
vector<pair<int,int>> paresBuenos(vector<pair<int,int>> codosuIngreso);
vector < hogar > armarRes(vector<pair<int,int>> ingresoCumple,eph_h th ,int h);
////////// fin ejercicio 8

////////// ejercicio 9
void cambiaRegionesGBAaPampeana(eph_h & th);
////// ej 10
float distanciaEuclediana(pair<float, float> centro, int latitud, int longitud);
bool hogarEnAnillo(int distDesde, int distHasta, pair<int, int> centro, hogar h);
int cantHogaresEnAnillo(int distDesde, int distHasta, pair<int, int> centro, eph_h th);
vector<int> hogaresEnAnillosConcentricos(vector<int> distancias, pair<int, int> centro, eph_h th);





///ej 11
bool sinIndividuos (hogar h, eph_i ti);
void quitarInd (eph_i &ti, pair<eph_h,eph_i> resultado);
hogar hogarCorrespondiente (individuo i, eph_h th, eph_i ti);
void quitarHog (eph_h &th, eph_i ti, pair<eph_h,eph_i> resultado);
