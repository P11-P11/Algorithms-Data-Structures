#include "ejercicios.h"
#include "auxiliares.h"
#include "definiciones.h"
using namespace std;
// Implementacion Problema 1


bool esEncuestaValida ( eph_h th, eph_i ti ) {
    bool esEncuestaValida = true;
    int cantidadIndividuos = ti.size();
    int cantidadHogares = th.size();
    int n = cantidadIndividuos;
    int h = cantidadHogares;
    bool sonMatrices =esMatrizDeNxM(ti,cantidadIndividuos,11) && esMatrizDeNxM(th,cantidadHogares,12);;
    bool NoesVacia = ( cantidadIndividuos > 0 && cantidadHogares > 0);
    if (!sonMatrices || !NoesVacia){return false;}
    bool Asociados = estanAsociados(th,ti,n,h);
    bool noHayRepetidos = sinRepetidos(th,ti,n,h);
    bool anioYtrimestre = anioYtrimestreIguales(th,ti,n,h);
    bool menosDe20 = menosDe20Personas(ti,n);
    bool IV2_II2 = IV2_MayorIgual_II2(th,h);
    bool categoricosInRange = categoricosEnRango(th,ti,n,h);
    vector <bool> condiciones = {sonMatrices,NoesVacia,Asociados,noHayRepetidos,anioYtrimestre,menosDe20,IV2_II2,categoricosInRange};
    int k = condiciones.size();
    for (int i = 0; i < k; ++i){
        if (condiciones[i] != true){ esEncuestaValida = false; break;}
    }
    return esEncuestaValida;
}

/////////////////////////////////////////////////////////

// Implementacion Problema 2


vector < int > histHabitacional ( eph_h th, eph_i ti, int region ) {
    int h = th.size();
    vector <int> resultado(maxHabitacionesDeRegion(th,h,region),0);
    int k = resultado.size();
    int indiceRes = 0;
    if (esEncuestaValida(th, ti)){
        for (int i = 1; i < k + 1  ; i++){
            int contador =0;
            for(int j=0; j<h; j++){
                if(th[j][9] == i && th[j][8] == 1 && th[j][6] == region){
                    contador++;
                }
            }
            resultado[indiceRes] = contador;
            indiceRes+=1;

        }

    }
    return resultado;

}



// Implementacion Problema 3
vector< pair < int, float > > laCasaEstaQuedandoChica ( eph_h th, eph_i ti ) {
    int h = th.size();
    int n = ti.size();
    vector< pair < int, float >> res = indiceHcRegion(th,h,ti,n);
    return res;

}

// Implementacion Problema 4
bool creceElTeleworkingEnCiudadesGrandes ( eph_h t1h, eph_i t1i, eph_h t2h, eph_i t2i ) {
    bool sonInteranualesHogar = (t1h[0][1] < t2h[0][1]);
    int h = t1h.size();
    int n =t1i.size();
    int hh = t2h.size();
    int nn = t2i.size();
    bool res = false;
    for (int i = 0; i < h ; ++i) {
        if (sonInteranualesHogar){
            bool trimestrales = mismoTrimestre(t1h,t2h);
            if (trimestrales){
                float trabajadores1 = trabjadoresTotales(t1i,n);
                float teleworkers1 = teleWorkers(t1h,h,t1i,n);
                float trabajadores2 = trabjadoresTotales(t2i,nn);
                float teleworkers2 = teleWorkers(t2h,hh,t2i,nn);
                float t1 = (static_cast<float>(teleworkers1)/trabajadores1);
                float t2 = (static_cast<float>(teleworkers2)/trabajadores2);
                if(t2>t1){res = true;}
            }
        }
        if (res == true){break;}
    }
    return res;
}
// Implementacion Problema 5

int costoSubsidioMejora(eph_h th, eph_i ti, int monto){
    int resultado = 0;
    for(hogar h : th){
        if(tieneCasaPropia(h) && tieneCasaChica(h, ti)){
            resultado += monto;
        }
    }
    return resultado;
}

// Implementacion Problema 6
join_hi generarJoin( eph_h th, eph_i ti ){
    vector<par_hi> resultado;
    for(hogar h : th){
        agregarIndividuosCorrespondientes(h, ti, resultado);
    }
    return resultado;

}

// Implementacion Problema 7

void ordenarRegionYCODUSU (eph_h & th, eph_i & ti) {
    int h = th.size();
    int n = ti.size();
    th = ordenarHogares(th,h);
    for (int i = 0; i < h ; ++i) {
        for (int j = 0; j < n ; ++j) {
            if (th[i][0] == ti[j][0]){
                ordenarIndividuos(ti,n,th);
            }

        }
    }
    return;
}

// Implementacion Problema 8

vector < hogar > muestraHomogenea( eph_h & th, eph_i & ti ){
    int n = ti.size();
    int h = th.size();
    vector<pair <int,int>> parCodIng = parCodosuIngreso(ti,n,th,h);
    vector<pair<int,int>> parCodIngBuenos = paresBuenos(parCodIng);
    vector<hogar> res = armarRes(parCodIngBuenos,th,h);
    return res;
}



// Implementacion Problema 9
void corregirRegion(eph_h & th, eph_i ti){
    cambiaRegionesGBAaPampeana(th);
}

// Implementacion Problema 10
vector<int> histogramaDeAnillosConcentricos( eph_h th, eph_i ti, pair<int, int> centro, vector<int> distancias ){
    return hogaresEnAnillosConcentricos(distancias, centro, th);
}


// Implementacion Problema 11

pair < eph_h, eph_i > quitarIndividuos(eph_i & ti, eph_h & th, vector < pair < int, dato > >  busqueda ){
    pair< eph_h, eph_i> resultado;
    //agrego a resultado todos los individuos y sus respectivos hogares que cumplen con la busqueda.
    for (int i = 0; i<ti.size(); i++){
        int matchs = 0;
        for (int j = 0; j<busqueda.size(); j++){
            if(ti[i][busqueda[j].first] == busqueda[j].second){
                matchs++;
            }
        }
        if(matchs == busqueda.size()){
            resultado.second.push_back(ti[i]);
            bool aparece = false;
            for (int j = 0; j<resultado.first.size(); j++){
                if(resultado.first[j][0] == ti[i][0]){
                    aparece = true;
                }
            }
            if (!aparece){resultado.first.push_back(hogarCorrespondiente(ti[i], th, ti));}
        }
    }
    quitarInd (ti, resultado);
    quitarHog (th, ti, resultado);
    return resultado;
}


