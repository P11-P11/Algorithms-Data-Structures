
#include "definiciones.h"
#include "auxiliares.h"
#include "gtest/gtest.h"
#include "ejercicios.h"
# include <utility >
//HOGCODUSU,HOGANO4,HOGTRIMESTRE,HOGLATITUD,HOGLONGITUD,II7,REGION,MAS_500,IV1,IV2,II2,II3
//0           1           2           3           4       5   6       7      8   9   10 11
//INDCODUSU,INDANO4,COMPONENTE,NIVEL_ED,TRIMESTRE,CH4,CH6,ESTADO,CAT_OCUP,P47T,PP04G
//0           1           2       3       5       6   7      8        9   10      11

bool esMatrizDeNxM (vector<vector<int>> mat,int n,int m){
    if(n == 0 || m == 0){return false;}
    else
        return (mat.size() == n && mat[0].size() == m);}
bool sinHogaresRepetidos(eph_h th, int h ){
    bool sinHogaresRepetidos = true;
    for (int i = 1; i < h; i++){
        if(th[i-1][0] == th[i][0]){sinHogaresRepetidos = false; break;}
    }
    return sinHogaresRepetidos;}
bool sinIndividuosRepetidos(eph_i ti , int n){
    bool sinIndividuosRepetidos = true;
    for (int i = 1; i < n; i++){
        if (ti[i-1][0] == ti[i][0] && ti[i-1][2] == ti[i][2]){
            sinIndividuosRepetidos = false;
            break;
        }

    }
    return sinIndividuosRepetidos;}
bool sinRepetidos(eph_h th, eph_i ti , int n, int h ){return sinHogaresRepetidos(th,  h ) && sinIndividuosRepetidos( ti ,  n);}
bool anioYtrimestreIguales(eph_h th, eph_i ti , int n, int h ){
    bool anioYtrimestreIgualesHogares = true;
    bool anioYtrimestreIgualesIndividuos = true;
//    if (th[0][1] < 0 || th[0][2] < 0) {anioYtrimestreIgualesHogares = false;}
    if (th[0][2] < 0) {anioYtrimestreIgualesHogares = false;}
    for (int i = 1; i < h; i++){
        if (th[i][2] < 0||th[i-1][1] != th[i][1] || th[i-1][2] != th[i][2]){
            anioYtrimestreIgualesHogares = false;
            break;}

    }
    if (ti[0][4] < 0) {anioYtrimestreIgualesIndividuos = false;}
    for (int i = 1; i < n; ++i) {
        if (ti[i][1] < 0 || ti[i][4] < 0){anioYtrimestreIgualesIndividuos = false;}
        else if (ti[i-1][1] != ti[i][1] || ti[i-1][4] != ti[i][4]){
            anioYtrimestreIgualesIndividuos = false;
            break;}
    }
    bool anioYtrimestreIguales = anioYtrimestreIgualesHogares && anioYtrimestreIgualesIndividuos;
    if (th[0][1] != ti[0][1] || th[0][2] != ti[0][4]){anioYtrimestreIguales = false;}
//    if (anioYtrimestreIgualesHogares == false && anioYtrimestreIgualesIndividuos == false){anioYtrimestreIguales = false;}
    return anioYtrimestreIguales;}
bool pertenece (vector <int> v, int x){
    int n = v.size();
    bool pertenece = false;
    for (int i = 0; i < n; i++){
        if (v[i] == x){
            pertenece = true;
            break;
        }
    }return pertenece;}
bool estanAsociados(eph_h th, eph_i ti , int n ,int h){
    bool estanAsociados = true;
    vector<int> columnaCeroTh;
    for (int i = 0; i < h; i++){
        columnaCeroTh.push_back(th[i][0]);
    }
    for (int i = 0; i < n; i++){
        if (!pertenece(columnaCeroTh,ti[i][0])){
            estanAsociados = false;
            break;
        }
    }
    return estanAsociados;}
bool menosDe20Personas(eph_i ti , int n){
    bool hayMenosDe20 = true;
    for (int i = 0; i < n; i++)
    {
        if (ti[i][2] > 21)
        {
            hayMenosDe20 = false;
            break;
        }
    }
    return hayMenosDe20;}
bool IV2_MayorIgual_II2(eph_h th, int h){
    bool sonIguales = true;
    for (int i = 0; i < h; i++){
        if (th[i][9] < th[i][10]){
            sonIguales = false;
            break;}
    }
    return sonIguales;}
bool categoricosIndividuoEnRango(eph_i ti , int n){
    bool enRango = true;
    vector <int> trimestre = {1,2,3,4};
    vector <int> ch4 = {1,2}; // j = 5
    vector <int> nivel_ed = {0,1}; // j = 3
    vector <int> estado = {0,1,-1}; // j =7
    vector <int>  cat_ocup = {0,1,2,3,4}; // j = 8
    vector <int> pp04g = {0,1,2,3,4,5,6,7,8,9,10}; //j = 10

    for (int i = 0; i < n ; ++i) {
        for (int j = 2; j < 11 ; ++j) {
            if (j == 2){
                if (ti[i][j] < 0){enRango = false;}
            }
            else if (j == 3){
                if(!pertenece(nivel_ed,ti[i][3])){enRango = false;}
            }
            else if (j == 4){
                if(!pertenece(trimestre,ti[i][4])){enRango = false;}
            }
            else if (j == 5){
                if(!pertenece(ch4,ti[i][5])){enRango = false;}
            }
            else if (j == 7){
                if(!pertenece(estado,ti[i][7])){enRango = false;}
            }
            else if (j == 8){
                if(!pertenece(cat_ocup,ti[i][8])){enRango = false;}
            }
            else if (j == 9){
                if (ti[i][j] < -1){enRango = false;}
            }
            else if (j == 10){
                if(!pertenece(pp04g,ti[i][10])){enRango = false;}
            }
        }
    }


    return enRango;
}
bool categoricosHogarEnRango(eph_h th, int h){
    vector<int> trimestre = {1,2,3,4};
    vector <int> II7 = {1,2,3}; //j = 5
    vector <int> region = {1,40,41,42,43,44};// j=6
    vector <int> mas500K = {0,1};// j= 7
    vector <int> IV1 = {1,2,3,4,5};// j = 8
    vector <int> II3 = {1,2}; // j = 11
    bool enRango = true;
    for (int i = 0; i < h ; ++i) {
        if (!pertenece(trimestre,th[i][2])){enRango = false;}
        else{for (int j = 5; j < 12 ; ++j) {
                if (j == 5){
                    if(!pertenece(II7,th[i][5])){enRango = false;}
                }
                else if (j == 6){
                    if(!pertenece(region,th[i][6])){enRango = false;}
                }
                else if (j == 7){
                    if(!pertenece(mas500K,th[i][7])){enRango = false;}
                }
                else if (j == 8){
                    if(!pertenece(IV1,th[i][8])){enRango = false;}
                }
                else if (j == 9 || j == 10){
                    if (th[i][j] < 0){ enRango = false;}
                }
                else if (j == 11){
                    if(!pertenece(II3,th[i][11])){enRango = false;}
                }
            }}

    }
    return enRango;
}
bool categoricosEnRango(eph_h th, eph_i ti, int n ,int h){return categoricosHogarEnRango(th,h) && categoricosIndividuoEnRango(ti ,  n);}

//////////////////////////////////////////////////////////////////////////
/// ejercicio 2

int maxHabitacionesDeRegion (eph_h th,int h,int region){
    int maximo = th[0][9];
    for (int i=0; i < h;i++){
        if (maximo < th[i][9] && th[i][6] == region){
            maximo = th[i][9];
        }
    }
    return maximo;
}

//// ejercicio 3

int contarApariciones(vector <int> v, int x){
    int apariciones = 0;
    int n = v.size();
    for (int i = 0; i < n ; ++i) {
        if (v[i] == x){apariciones +=1;}
    }
    return apariciones;
}
//genera vectores con los codosu de hogares o individuo
vector <int> vectorCodosuIndividuo(eph_i ti, int n){
    vector<int> codosusInd;
    for (int i = 0; i < n ; ++i) {
        codosusInd.push_back(ti[i][0]);
    }
    return codosusInd;
}
vector <int> vectorCodosuHogar(eph_h th, int h){
    vector<int> codosusHog;
    for (int i = 0; i < h ; ++i) {
        codosusHog.push_back(th[i][0]);
    }
    return codosusHog;
}
// genera vector con cantidad de casa hacinamiento critico
vector<int> hcPorRegion(eph_i ti, int n,eph_h th, int h){
    vector<int> codosus = vectorCodosuIndividuo(ti,n);
    vector<int> HcRegion(6,0);
    int numeroAparicionesCodosu = 0;
    for (int i = 0; i < h ; ++i) {
        int  numeroHabitaciones = th[i][10];
        int hc = 0;
        // es caba
        if (th[i][6] == 1 && th[i][7] == 0 && th[i][8] == 1){
            numeroAparicionesCodosu = contarApariciones(codosus,th[i][0]);
            if ( numeroAparicionesCodosu > 3 * numeroHabitaciones){ hc = 1;}
            HcRegion[0] += hc;
        }
            // es noa
        else if(th[i][6] == 40 && th[i][7] == 0 && th[i][8] == 1){
            numeroAparicionesCodosu = contarApariciones(codosus,th[i][0]);
            if (numeroAparicionesCodosu > 3 * numeroHabitaciones){ hc = 1;}
            HcRegion[1] += hc;
        }
            // es nea
        else if(th[i][6] == 41 && th[i][7] == 0 && th[i][8] == 1) {
            numeroAparicionesCodosu = contarApariciones(codosus, th[i][0]);
            if ( numeroAparicionesCodosu > 3 * numeroHabitaciones){ hc = 1;}
            HcRegion[2] += hc;
        }
            // es cuyo
        else if (th[i][6] == 42 && th[i][7] == 0 && th[i][8] == 1) {
            numeroAparicionesCodosu = contarApariciones(codosus, th[i][0]);
            if (numeroAparicionesCodosu > 3 * numeroHabitaciones){ hc = 1;}
            HcRegion[3] += hc;
        }
            // es pampeana
        else if (th[i][6] == 43 && th[i][7] == 0 && th[i][8] == 1) {
            numeroAparicionesCodosu = contarApariciones(codosus, th[i][0]);
            if ( numeroAparicionesCodosu > 3 * numeroHabitaciones){ hc = 1;}
            HcRegion[4] += hc;
        }
            // es patagonia
        else if (th[i][6] == 44 && th[i][7] == 0 && th[i][8] == 1) {
            numeroAparicionesCodosu = contarApariciones(codosus, th[i][0]);
            if (numeroAparicionesCodosu > 3 * numeroHabitaciones){ hc = 1;}
            HcRegion[5] += hc;
        }
    }
    return HcRegion;
}
// genera vector cantidad de casas por region
vector<int> casaPorRegion(eph_h th,int h){
    vector<int> cantidadDeCasaEnRegion(6,0);
    for (int i = 0; i < h ; ++i) {
        // es caba
        if (th[i][6] == 1  && th[i][8] == 1){
            cantidadDeCasaEnRegion[0]++;
        }
            // es noa
        else if(th[i][6] == 40  && th[i][8] == 1){
            cantidadDeCasaEnRegion[1]++;
        }
            // es nea
        else if(th[i][6] == 41 && th[i][8] == 1) {
            cantidadDeCasaEnRegion[2]++;
        }
            // es cuyo
        else if (th[i][6] == 42 && th[i][8] == 1) {
            cantidadDeCasaEnRegion[3]++;
        }
            // es pampeana
        else if (th[i][6] == 43 && th[i][8] == 1) {
            cantidadDeCasaEnRegion[4]++;
        }
            // es patagonia
        else if (th[i][6] == 44 && th[i][8] == 1) {
            cantidadDeCasaEnRegion[5]++;
        }
    }
    return cantidadDeCasaEnRegion;
}
// hace lo pedido por el problema
vector<pair<int,float>> indiceHcRegion(eph_h th, int h,eph_i ti, int n){
    vector<int> cantidadHc = hcPorRegion(ti,n,th,h);
    vector<int> cantidadCasas = casaPorRegion(th,h);
    vector <int> region ={1,40,41,42,43,44};
    pair<int,float> indiceHc;
    vector<pair<int,float>> res;
    float promedio = 1.0;
    for (int i = 0; i < 6 ; ++i) {
        if(cantidadCasas[i] == 0){promedio = 0.0;}
        else{promedio = static_cast<float>(cantidadHc[i])/cantidadCasas[i];}
        indiceHc.first = region[i];
        indiceHc.second = promedio;
        res.push_back(indiceHc);
    }

    return res;
}


//// con el par codosu inquilino voy a ir a la matriz de hogares
//// voy a buscar el codosu en matriz de hogares
//// y generar el par inquilino habitaciones

////////////////////////////////////////////////////
////ejercicio 4////
int teleWorkers(eph_h th, int h, eph_i ti, int n){
    int teleworker = 0;
    for (int i = 0; i < h ; ++i) {
        bool laCasaCumple = (th[i][7] == 1 && (th[i][8] == 1 || th[i][8] == 2) && th[i][11]== 1);
        if (laCasaCumple){
            for (int j = 0; j < n ; ++j) {
                bool  viveEnlaCasa = (th[i][0] == ti[j][0]);
                bool individuoCumple = (ti[j][7] == 1 && ti[j][10] == 6);
                if (viveEnlaCasa && individuoCumple){
                    teleworker++;
                }
            }
        }
    }

    return teleworker;
}
int trabjadoresTotales(eph_i ti, int n){
    int laburantes = 0;
    for (int i = 0; i < n ; ++i) {
        if(ti[i][7] == 1){
            laburantes++;
        }
    }
    return laburantes;
}
bool mismoTrimestre( eph_h t1h,  eph_h t2h) {
    bool trimestre = false;
    int h = t1h.size();
    int hh = t2h.size();
    for (int i = 0; i < h; ++i) {
        for (int j = 0; j < hh; ++j) {
            if (t1h[i][2] == t2h[j][2]) { trimestre = true; }
        }
        if (trimestre == true){break;}
    }
    return trimestre;
}
//////////////////////////////
/// ejercicio 5
bool tieneCasaPropia(hogar h){
    // h[5] es h[II7]
    return h[5] == 1;
}
int cantHabitantes(hogar h, eph_i ti){
    int habitantes = 0;
    for(individuo i : ti){
        if(i[0] == h[0]){
            habitantes++;
        }
    }
    return habitantes;
}
bool tieneCasaChica(hogar h, eph_i ti){
    // h[10] es h[II2]
    return cantHabitantes(h, ti) - 2 > h[10];
}

/////////fin ejercicio 5//////////


//////////////////// ejercicio 6
vector<int> generaFilaHogares(eph_h th,int i){
    vector<int> filaH;
    int h = th[0].size();
//    int i; // fila que quiero agregar
    for (int j = 0; j < h ; ++j) {
        filaH.push_back(th[i][j]);
    }
    return filaH;
}
vector<int> generaFilaIndividuos(eph_i ti,int i){
    vector<int> filaI;
    int n = ti[0].size();
//    int i; // fila que quiero agregar
    for (int j = 0; j < n ; ++j) {
        filaI.push_back(ti[i][j]);
    }
    return filaI;
}
void agregarIndividuosCorrespondientes(hogar h, eph_i ti, vector<par_hi> & resultado){
    int codosu = h[0];
    for(individuo i : ti){
        if(i[0] == codosu){
            resultado.push_back(make_pair(h, i));
        }
    }
}
//////////// fin ejercicio 6
//////// ejercicio 7
void burbujeoHogares(eph_h &th,int h){
    for (int i = 1; i < h ; ++i) {
        if (th[i-1][6] > th[i][6]){
            th[i].swap(th[i-1]);
        }
        else if (th[i-1][6] == th[i][6] && th[i-1][0] > th[i][0]){
            th[i].swap(th[i-1]);
        }
    }
}
eph_h ordenarHogares (eph_h th,int h){
    for (int i = 0; i < h ; ++i) {
        burbujeoHogares(th,h);
    }
    return th;
}
// Dado un codosu, busco su indice
int buscarIndiceCodosu(int codosu, eph_h th){
    int h = th.size();
    int indice = -1;
    for(int i = 0; i < h; i++){
        if(th[i][0] == codosu){
            indice = i;
        }
    }
    return indice;
}
/* Tengo 2 individuos y dados sus codosus los busco en th con el indice
La forma de comparar es con los índices, este es el concepto de "estar antes"
*/
bool estaAntesHogar(individuo individuo1, individuo individuo2, eph_h th){
    int codosu1 = individuo1[0];
    int codosu2 = individuo2[0];
    int indice1 = buscarIndiceCodosu(codosu1, th);
    int indice2 = buscarIndiceCodosu(codosu2, th);
    return indice1 > indice2;

}
void swap(eph_i &ti, int i, int j){
    vector<int> temp = ti[i];
    ti[i] = ti[j];
    ti[j] = temp;
}
// Al ser ti un inout es un void, no hace falta devolverlo
void ordenarIndividuos(eph_i &ti , int n, eph_h thOrdenado){
    // Ordeno primero por codosus
    for(int i = 0; i<n; i++){
        for(int j=i+1; j<n; j++){
            // La idea es usar lo indices de thOrdenado
            if(estaAntesHogar(ti[i], ti[j], thOrdenado)){
                swap(ti, i,j);
            }
        }
    }

    // Los Codosus que son iguales los ordeno por Componente

    for(int i = 0; i < n; i++){
        for(int j = i+1; j < n; j++){
            if((ti[i][0] == ti[j][0]) && (ti[i][2] > ti[j][2])){
                swap(ti, i, j);
            }
        }
    }

    //return ti;
}
////////////EJ 8
void swap(vector<int> &lista, int i, int j){
    int k = lista[i];
    lista[i]= lista[j];
    lista[j]=k;
}
int ingresoDelHogar(eph_i ti, int n , int codosu){
    int ingresos = 0;
    for (int i = 0; i < n ; ++i) {
        if(ti[i][0] == codosu && ti[i][9] != -1){
            ingresos += ti[i][9];
        }
    }
    return ingresos;
}
//genera un vector de pares (codosu,$) que aparte respeta el orden de aparicion de codosus del hogar
vector<pair <int,int>> parCodosuIngreso(eph_i ti,int n,eph_h th,int h){
    pair <int,int> codosuIngreso;
    vector<pair <int,int>> data;
    for (int i = 0; i < h ; ++i) {
        for (int j = 0; j < n ; ++j) {
            codosuIngreso.first = th[i][0];
            codosuIngreso.second = ingresoDelHogar(ti,n,th[i][0]);
        }
        data.push_back(codosuIngreso);

    }
    return data;
}

// ordeno datos
void burbujeoIngresos(vector<pair <int,int>> &codosuIngreso){
    int k = codosuIngreso.size();
    for (int i = 1; i < k ; ++i) {
        if (codosuIngreso[i-1].second > codosuIngreso[i].second){
            codosuIngreso[i].swap(codosuIngreso[i-1]);
        }
    }
}
void ordenarParPorIngreso(vector<pair <int,int>> &codosuIngreso){
    int k = codosuIngreso.size();
    for (int i = 0; i < k ; ++i) {
        burbujeoIngresos(codosuIngreso);
    }

}
vector<pair<int,int>> paresBuenos(vector<pair<int,int>> codosuIngreso) {
    ordenarParPorIngreso(codosuIngreso);
    int k = codosuIngreso.size();
    int cota = codosuIngreso[k - 1].second - codosuIngreso[0].second;
    vector<pair<int, int>> res = {};
    vector<pair<int, int>> congruentes = {};
    vector<pair<int, int>> resAux = {};
    vector<pair<int, int>> resAuxUnos = {};
    int indiceRes = 0;
    for (int i = 0; i < k - 1; ++i) {
        if (codosuIngreso[i].second != 0 && codosuIngreso[i].second != 1 && codosuIngreso[i].second != -1){
            if (res.empty() && codosuIngreso[i+1].second - codosuIngreso[i].second == 1){
                res.push_back(codosuIngreso[i]);
            }
            if (!res.empty() && codosuIngreso[i].second - res[indiceRes].second == 1){
                res.push_back(codosuIngreso[i]);
                indiceRes++;
            }
        }
    }

    if (res.size() < 3) {
        res = {};
    }
    if ((res.size() > 2 && resAuxUnos.empty()) || ((res.size() > resAuxUnos.size()) && !resAuxUnos.empty())) {
        resAuxUnos = res;
        res = {};
    }

    for (int i = 2; i < cota + 1; ++i) {
        for (int j = 0; j < k; ++j) {
            if (codosuIngreso[j].second != 0 && codosuIngreso[j].second != 1 && codosuIngreso[j].second != -1 && codosuIngreso[j].second % i == 0) {
                congruentes.push_back(codosuIngreso[j]);
            }
        }
        if (congruentes.size() > 2) {
            for (int j = 0; j < congruentes.size() - 1; ++j) {

                if (res.empty() && congruentes[j + 1].second - congruentes[j].second == i) {
                    res.push_back(congruentes[j]);
                } else if (!res.empty() && congruentes[j].second - res[indiceRes].second == i) {
                    res.push_back(congruentes[j]);
                    indiceRes++;
                }
            }
            indiceRes = 0;
            if (res.size() < 3) {
                res = {};
            }
            if ((res.size() > 2 && resAux.empty()) || ((res.size() > resAux.size()) && !resAux.empty())) {
                resAux = res;
                res = {};
            }
        }
        congruentes = {};
    }
    if (resAux.size() > resAuxUnos.size()){
        res = resAux;
    }
    else res = resAuxUnos;
    return res;
}


vector < hogar > armarRes(vector<pair<int,int>> ingresoCumple,eph_h th ,int h){
    int k = ingresoCumple.size();
    vector < hogar > res;
    for (int i = 0; i < k ; ++i) {
        for (int j = 0; j < h ; ++j) {
            if (th[j][0] ==ingresoCumple[i].first){
                vector<int> fila = generaFilaHogares(th,j);
                res.push_back(fila);
            }
        }

    }
    return res;
}
/////// ejercicio 9
void cambiaRegionesGBAaPampeana(eph_h & th){
    int n = th.size();
    for(int i = 0; i < n; i++){
        if(th[i][6] == 1){
            th[i][6] = 43;
        }
    }
}
///////// ej 10
// Calculo la cantidad de hogares que hay en un anillo en particular
float distanciaEuclediana(pair<float, float> centro, int latitud, int longitud){
    int a = pow(centro.first - latitud, 2);
    int b = pow(centro.second - longitud, 2);
    float distancia = sqrt(a+b);
    return distancia;
}

// Calculo la cantidad de hogares que hay en un anillo en particular
bool hogarEnAnillo(int distDesde, int distHasta, pair<int, int> centro, hogar h){
    // h[3] es Latitud y h[4] es Longitud
    // Así está especificado
    return distDesde < distanciaEuclediana(centro, h[3], h[4]) && distanciaEuclediana(centro, h[3], h[4]) <= distHasta;
}

int cantHogaresEnAnillo(int distDesde, int distHasta, pair<int, int> centro, eph_h th){
    int cantidad = 0;
    for(hogar h : th){
        // Si estan en el anillo sumo 1
        if(hogarEnAnillo(distDesde, distHasta, centro, h)){
            cantidad++;
        }
    }
    return cantidad;
}

vector<int> hogaresEnAnillosConcentricos(vector<int> distancias, pair<int, int> centro, eph_h th){
    vector<int> result;
    // Me aseguro que el primero sea distDesde = 0. Es el primer anillo
    result.push_back(cantHogaresEnAnillo(0, distancias[0], centro, th));
    for(int i = 0; i < distancias.size() - 1;){
        result.push_back(cantHogaresEnAnillo(distancias[i], distancias[i+1], centro, th));
        i++;
    }
    return result;
}









//////ej 11
hogar hogarCorrespondiente (individuo i, eph_h th, eph_i ti){
    for (int j = 0; j<th.size(); j++){
        if (th[j][0] == i[0]){
            return th[j];
        }
    }
}

bool sinIndividuos (hogar h, eph_i ti){
    bool esVacia = true;
    for(int j = 0; j<ti.size(); j++){
        if(ti[j][0] == h[0]){
            esVacia = false;
        }
    }
    return esVacia;
}

void quitarInd (eph_i &ti, pair<eph_h,eph_i> resultado){
    eph_i auxi (0);
    for (int i = 0; i<ti.size(); i++){
        bool aparece = false;
        for (int j = 0; j<resultado.second.size(); j++){
            //Agrego a auxi todos los individuos cuyo Indcodusu y componente no aparecen en resultado
            if (ti[i][0] == resultado.second[j][0] && ti[i][2] == resultado.second[j][2]){
                aparece = true;
            }
        }
        if (!aparece){
            auxi.push_back(ti[i]);
        }
    }
    ti = auxi;
}

void quitarHog (eph_h &th, eph_i ti, pair<eph_h,eph_i> resultado){
    eph_h auxh (0);
    for (int i = 0; i<th.size(); i++){
        bool aparece = false;
        for(int j = 0; j<resultado.first.size(); j++){
            //Agrego a auxh a todos los hogares que no aparecen en resultado.
            if (th[i][0] == resultado.first[j][0] && sinIndividuos(th[i],ti)){
                aparece = true;
            }
        }
        if (!aparece){
            auxh.push_back(th[i]);
        }
    }
    th = auxh;
}


